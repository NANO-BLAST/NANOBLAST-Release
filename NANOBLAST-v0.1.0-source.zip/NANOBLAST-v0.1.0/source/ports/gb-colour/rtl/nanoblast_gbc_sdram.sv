// SDRAM controller for the GW2AR-18 embedded 64 Mbit SDRAM (2M x 32, 4 banks,
// 2048 rows, 256 columns), running in the Game Boy clk_sys domain (33.75 MHz).
// The chip clock is clk_sys shifted by 180 degrees, so commands launched on a
// rising edge are sampled by the SDRAM half a cycle later.
//
// Every access is a single word with auto-precharge and takes 5 cycles:
//   c0 ACTIVE, c2 READ/WRITE (A10=1), read data captured RD_CAPTURE cycles after c2.
//
// Port priorities:
//   1. Cart port (Game Boy cartridge bus). Reads are triggered by the rising edge of
//      the core's sdram_rd strobe (start of each bus cycle), writes by the rising edge
//      of cram_wr. Data is ready ~6 cycles after the strobe, well before the CPU latches
//      it (>= 12 cycles later even in double speed mode).
//   2. Refresh and the generic low-priority port. These only start while lp_block is
//      low; the core drives lp_block in the cycles just before a cart strobe can occur,
//      so a cart access never has to wait.
//
// Power saving:
//   pd_en   precharge power-down (CKE low) whenever there is nothing to do; leaving it
//           costs 2 cycles, so a cart read is ready ~8 cycles after its strobe.
//   sr_req  self refresh while it is high and the controller is idle (sleep mode).
// NANOBLAST adaptation: 64.8 MHz timing, artwork burst port, cart readiness.
module nanoblast_gbc_sdram #(
    parameter RD_CAPTURE = 2,      // cycles from READ command to data capture
    parameter INIT_WAIT  = 13000,   // >200 us at 33.75 MHz
    parameter REFRESH_INTERVAL = 506 // 7.4 us
) (
    input             clk,
    input             resetn,          // hold low until PLL locked
    output reg        ready,
    output cart_ready,
    input bg_enable,bg_req,input [19:0]bg_addr,
    output reg bg_ack=0,bg_valid=0,output reg [31:0]bg_data=0,output reg [8:0]bg_word=0,

    // cart port (byte access)
    input             cart_rd_strobe,  // level; rising edge starts a read
    input             cart_wr_strobe,  // level; rising edge starts a write
    input      [22:0] cart_addr,       // byte address
    input       [7:0] cart_din,
    output reg  [7:0] cart_dout,

    // low priority port (word access)
    input             lp_block,
    input             pd_en,
    input             sr_req,
    input             lp_req,          // hold until lp_ack
    output reg        lp_ack,          // one cycle: request accepted
    input             lp_we,
    input      [20:0] lp_addr,         // word address
    input      [31:0] lp_wdata,
    input       [3:0] lp_be,
    output reg [31:0] lp_rdata,
    output reg        lp_rvalid,       // one cycle: lp_rdata valid for the last read

    // SDRAM pins
    output            O_sdram_clk,
    output reg        O_sdram_cke,
    output reg        O_sdram_cs_n,
    output reg        O_sdram_ras_n,
    output reg        O_sdram_cas_n,
    output reg        O_sdram_wen_n,
    output reg  [3:0] O_sdram_dqm,
    output reg [10:0] O_sdram_addr,
    output reg  [1:0] O_sdram_ba,
    inout      [31:0] IO_sdram_dq,

    input             clk_sdram_p      // clk_sys @ 180 deg
);

assign O_sdram_clk = clk_sdram_p;

localparam CMD_NOP       = 3'b111;
localparam CMD_ACTIVE    = 3'b011;
localparam CMD_READ      = 3'b101;
localparam CMD_WRITE     = 3'b100;
localparam CMD_PRECHARGE = 3'b010;
localparam CMD_REFRESH   = 3'b001;
localparam CMD_LOADMODE  = 3'b000;

// CAS latency 2, burst length 1, sequential, single write
localparam [10:0] MODE_REG = 11'b000_0_00_010_0_000;

reg [31:0] dq_out;
reg        dq_oe;
assign IO_sdram_dq = dq_oe ? dq_out : 32'bz;

task automatic cmd(input [2:0] c);
    {O_sdram_ras_n, O_sdram_cas_n, O_sdram_wen_n} <= c;
endtask

// ---------------------------------------------------------------- strobes
reg cart_rd_d, cart_wr_d;
reg cart_rd_pend, cart_wr_pend;
reg [22:0] cart_rd_addr, cart_wr_addr;
reg  [7:0] cart_wr_data;

// ---------------------------------------------------------------- refresh timer
reg [8:0] ref_cnt;
reg       ref_pend;

// ---------------------------------------------------------------- sequencer
localparam S_INIT = 0, S_IDLE = 1, S_ACCESS = 2;
reg [3:0] state;
localparam B_ACT=3,B_READ=4,B_DRAIN=5,B_PRE=6;
reg [22:0]bg_address=0;reg[8:0]bg_issued=0,bg_received=0;
reg[1:0]bg_pipe=0;reg bg_target=0;reg[2:0]bg_wait=0;
assign cart_ready=!(cart_rd_pend|cart_wr_pend|(cart_rd_strobe&~cart_rd_d)|(cart_wr_strobe&~cart_wr_d)|(state==S_ACCESS&&acc_cart));
reg [13:0] init_cnt;
reg  [2:0] cyc;            // cycle within access
reg        acc_we, acc_ref;
reg        acc_cart, acc_lp;
reg [20:0] acc_waddr;
reg [31:0] acc_wdata;
reg  [3:0] acc_be;
reg  [1:0] acc_lane;
reg  [3:0] xp_cnt;         // NOP cycles after CKE goes high again
reg  [1:0] idle_cnt;       // idle cycles before power-down (lets auto precharge finish)
reg        in_sr;

// read data capture pipeline: bit0 = cart, bit1 = lp, plus byte lane
reg [RD_CAPTURE:0] cap_cart, cap_lp;
reg  [1:0] cap_lane [0:RD_CAPTURE];

always @(posedge clk) begin
    if (!resetn) begin
        state        <= S_INIT;
        init_cnt     <= 0;
        ready        <= 0;
        O_sdram_cke  <= 0;
        O_sdram_cs_n <= 1;
        cmd(CMD_NOP);
        O_sdram_dqm  <= 4'hF;
        O_sdram_addr <= 0;
        O_sdram_ba   <= 0;
        dq_oe        <= 0;
        cart_rd_pend <= 0;
        cart_wr_pend <= 0;
        cart_rd_d    <= 1;
        cart_wr_d    <= 1;
        ref_cnt      <= 0;
        ref_pend     <= 0;
        lp_ack       <= 0;
        cap_cart     <= 0;
        bg_ack<=0;bg_valid<=0;bg_word<=0;bg_data<=0;bg_pipe<=0;bg_issued<=0;bg_received<=0;bg_address<=0;bg_target<=0;bg_wait<=0;
        cap_lp       <= 0;
        xp_cnt       <= 0;
        idle_cnt     <= 0;
        in_sr        <= 0;
    end else begin
        cmd(CMD_NOP);
        bg_valid<=0;bg_pipe<={bg_pipe[0],1'b0};
        if(bg_wait!=0)bg_wait<=bg_wait-1'b1;
        if(bg_pipe[1])begin bg_data<=IO_sdram_dq;bg_word<=bg_received;bg_valid<=1;bg_received<=bg_received+1'b1;end
        dq_oe  <= 0;
        lp_ack <= 0;

        // strobe edge detection; latch the address at the edge
        cart_rd_d <= cart_rd_strobe;
        cart_wr_d <= cart_wr_strobe;
        if (cart_rd_strobe & ~cart_rd_d) begin
            cart_rd_pend <= 1;
            cart_rd_addr <= cart_addr;
        end
        if (cart_wr_strobe & ~cart_wr_d) begin
            cart_wr_pend <= 1;
            cart_wr_addr <= cart_addr;
            cart_wr_data <= cart_din;
        end

        if (ref_cnt == REFRESH_INTERVAL - 1) begin
            ref_cnt  <= 0;
            ref_pend <= 1;
        end else
            ref_cnt <= ref_cnt + 1'd1;

        case (state)
        S_INIT: begin
            init_cnt    <= init_cnt + 1'd1;
            O_sdram_cke <= 1;
            O_sdram_cs_n <= 0;
            case (init_cnt)
                INIT_WAIT:      begin cmd(CMD_PRECHARGE); O_sdram_addr <= 11'b100_0000_0000; end
                INIT_WAIT + 4,
                INIT_WAIT + 12,
                INIT_WAIT + 20,
                INIT_WAIT + 28,
                INIT_WAIT + 36,
                INIT_WAIT + 44,
                INIT_WAIT + 52,
                INIT_WAIT + 60: cmd(CMD_REFRESH);
                INIT_WAIT + 68: begin cmd(CMD_LOADMODE); O_sdram_addr <= MODE_REG; O_sdram_ba <= 0; end
                INIT_WAIT + 72: begin state <= S_IDLE; ready <= 1; O_sdram_dqm <= 4'h0; end
                default: ;
            endcase
        end

        S_IDLE: begin
            acc_cart <= 0;
            acc_lp   <= 0;
            acc_ref  <= 0;
            acc_we   <= 0;
            cyc      <= 0;
            if (!O_sdram_cke) begin
                // in power-down or self refresh: wake up for any work or when released
                // (self refresh refreshes on its own, so ref_pend only ends a power-down)
                if (cart_rd_pend | (cart_rd_strobe & ~cart_rd_d) | cart_wr_pend | lp_req |
                    (in_sr ? ~sr_req : (ref_pend | ~pd_en))) begin
                    O_sdram_cke <= 1;
                    xp_cnt      <= in_sr ? 4'd8 : 4'd1;
                    if (in_sr) ref_pend <= 1;
                    in_sr       <= 0;
                end
                idle_cnt <= 0;
            end else if (xp_cnt != 0) begin
                xp_cnt   <= xp_cnt - 1'd1;
                idle_cnt <= 0;
            end else if (cart_rd_pend | (cart_rd_strobe & ~cart_rd_d)) begin
                // read (also covers a strobe arriving this very cycle)
                logic [22:0] a;
                a = cart_rd_pend ? cart_rd_addr : cart_addr;
                cart_rd_pend <= 0;
                acc_cart  <= 1;
                acc_waddr <= a[22:2];
                acc_lane  <= a[1:0];
                state     <= S_ACCESS;
                cmd(CMD_ACTIVE);
                O_sdram_ba   <= a[22:21];
                O_sdram_addr <= a[20:10];
            end else if (cart_wr_pend) begin
                cart_wr_pend <= 0;
                acc_cart  <= 1;
                acc_we    <= 1;
                acc_waddr <= cart_wr_addr[22:2];
                acc_wdata <= {4{cart_wr_data}};
                acc_be    <= 4'b0001 << cart_wr_addr[1:0];
                state     <= S_ACCESS;
                cmd(CMD_ACTIVE);
                O_sdram_ba   <= cart_wr_addr[22:21];
                O_sdram_addr <= cart_wr_addr[20:10];
            end else if (ref_pend & ~lp_block) begin
                ref_pend <= 0;
                acc_ref  <= 1;
                state    <= S_ACCESS;
                cmd(CMD_REFRESH);
            end else if(bg_enable&&bg_req!=bg_ack&&!lp_block)begin
                bg_address<=23'h600000+bg_addr;bg_target<=bg_req;bg_issued<=0;bg_received<=0;
                O_sdram_ba<=2'b11;O_sdram_addr<={1'b0,bg_addr[19:10]};
                cmd(CMD_ACTIVE);bg_wait<=1;state<=B_ACT;
            end else if (lp_req & ~lp_block) begin
                lp_ack    <= 1;
                acc_lp    <= 1;
                acc_we    <= lp_we;
                acc_waddr <= lp_addr;
                acc_wdata <= lp_wdata;
                acc_be    <= lp_be;
                state     <= S_ACCESS;
                cmd(CMD_ACTIVE);
                O_sdram_ba   <= lp_addr[20:19];
                O_sdram_addr <= lp_addr[18:8];
            end else if (idle_cnt != 2'd3) begin
                idle_cnt <= idle_cnt + 1'd1;
            end else if (sr_req && !lp_req) begin
                cmd(CMD_REFRESH);               // with CKE low: self refresh entry
                O_sdram_cke <= 0;
                in_sr       <= 1;
            end else if (pd_en && !ref_pend) begin
                O_sdram_cke <= 0;               // precharge power-down
            end
        end

        S_ACCESS: begin
            idle_cnt <= 0;
            cyc <= cyc + 1'd1;
            if (cyc == 3'd1 && !acc_ref) begin
                // column command with auto precharge
                O_sdram_addr <= {3'b100, acc_waddr[7:0]};
                if (acc_we) begin
                    cmd(CMD_WRITE);
                    dq_out      <= acc_wdata;
                    dq_oe       <= 1;
                    O_sdram_dqm <= ~acc_be;
                end else begin
                    cmd(CMD_READ);
                    O_sdram_dqm <= 4'h0;
                end
            end else
                O_sdram_dqm <= 4'h0;
            if (cyc == 3'd4) state <= S_IDLE;   // ACT at c0 .. next ACT at c5 (cycle after IDLE)
        end
        B_ACT:if(bg_wait==0)state<=B_READ;
        B_READ:begin
            cmd(CMD_READ);O_sdram_addr<={3'b000,bg_address[9:2]};O_sdram_dqm<=0;
            bg_pipe[0]<=1;bg_issued<=bg_issued+1'b1;bg_address<=bg_address+4;
            if(bg_issued==319||bg_address[9:2]==255)state<=B_DRAIN;
        end
        B_DRAIN:if(bg_pipe==0)begin
            cmd(CMD_PRECHARGE);O_sdram_addr<=11'b10000000000;bg_wait<=1;state<=B_PRE;
        end
        B_PRE:if(bg_wait==0)begin
            if(bg_issued==320)begin bg_ack<=bg_target;state<=S_IDLE;end
            else begin O_sdram_addr<=bg_address[20:10];cmd(CMD_ACTIVE);bg_wait<=1;state<=B_ACT;end
        end
        default: state <= S_INIT;
        endcase

        // capture pipeline (stage 0 is loaded with the READ command)
        cap_cart <= {cap_cart[RD_CAPTURE-1:0], (state == S_ACCESS && cyc == 3'd1 && !acc_ref && !acc_we && acc_cart)};
        cap_lp   <= {cap_lp[RD_CAPTURE-1:0],   (state == S_ACCESS && cyc == 3'd1 && !acc_ref && !acc_we && acc_lp)};
        cap_lane[0] <= acc_lane;
        for (int i = 1; i <= RD_CAPTURE; i++) cap_lane[i] <= cap_lane[i-1];
    end
end

// read data capture
always @(posedge clk) begin
    lp_rvalid <= 0;
    if (cap_cart[RD_CAPTURE-1]) begin
        case (cap_lane[RD_CAPTURE-1])
            2'd0: cart_dout <= IO_sdram_dq[7:0];
            2'd1: cart_dout <= IO_sdram_dq[15:8];
            2'd2: cart_dout <= IO_sdram_dq[23:16];
            2'd3: cart_dout <= IO_sdram_dq[31:24];
        endcase
    end
    if (cap_lp[RD_CAPTURE-1]) begin
        lp_rdata  <= IO_sdram_dq;
        lp_rvalid <= 1;
    end
end

endmodule
