;MIT License
;
;Copyright (c) 2015-2023 Lior Halphon
;
;Permission is hereby granted, free of charge, to any person obtaining a copy
;of this software and associated documentation files (the "Software"), to deal
;in the Software without restriction, including without limitation the rights
;to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
;copies of the Software, and to permit persons to whom the Software is
;furnished to do so, subject to the following conditions:
;
;The above copyright notice and this permission notice shall be included in all
;copies or substantial portions of the Software.
;
;THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
;IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
;FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
;AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
;LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
;OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
;SOFTWARE.

INCLUDE	"hardware.inc"

SECTION "BootCode", ROM0[$0]
Start:
; Init stack pointer
    ld sp, $fffe

; Clear memory VRAM
    ld hl, $8000

.clearVRAMLoop
    ldi [hl], a
    bit 5, h
    jr z, .clearVRAMLoop

; Init Audio
    ld a, $80
    ldh [rNR52], a
    ldh [rNR11], a
    ld a, $f3
    ldh [rNR12], a
    ldh [rNR51], a
    ld a, $77
    ldh [rNR50], a

; Init BG palette to white
    ld a, $0
    ldh [rBGP], a

; Load logo from ROM.
; A nibble represents a 4-pixels line, 2 bytes represent a 4x4 tile, scaled to 8x8.
; Tiles are ordered left to right, top to bottom.
    ld de, $104 ; Logo start
    ld hl, $8010 ; This is where we load the tiles in VRAM

.loadLogoLoop
    ld a, [de] ; Read 2 rows
    ld b, a
    call DoubleBitsAndWriteRow
    call DoubleBitsAndWriteRow
    inc de
    ld a, e
    xor $34 ; End of logo
    jr nz, .loadLogoLoop

; Load trademark symbol
    ld de, TrademarkSymbol
    ld c,$08
.loadTrademarkSymbolLoop:
    ld a,[de]
    inc de
    ldi [hl],a
    inc hl
    dec c
    jr nz, .loadTrademarkSymbolLoop

; Set up tilemap
    ld a,$19      ; Trademark symbol
    ld [$9910], a ; ... put in the superscript position
    ld hl,$992f   ; Bottom right corner of the logo
    ld c,$c       ; Tiles in a logo row
.tilemapLoop
    dec a
    jr z, .tilemapDone
    ldd [hl], a
    dec c
    jr nz, .tilemapLoop
    ld l,$0f ; Jump to top row
    jr .tilemapLoop
.tilemapDone

    ; Turn on LCD
    ld a, $91
    ldh [rLCDC], a

    ld a, $f1 ; Packet magic, increases by 2 for every packet
    ldh [_HRAM], a
    ld hl, $104 ; Header start
    
    xor a
    ld c, a ; JOYP

.sendCommand
    xor a
    ld [c], a
    ld a, $30
    ld [c], a
    
    ldh a, [_HRAM]
    call SendByte
    push hl
    ld b, $e
    ld d, 0
    
.checksumLoop
    call ReadHeaderByte
    add d
    ld d, a
    dec b
    jr nz, .checksumLoop
    
    ; Send checksum
    call SendByte
    pop hl
    
    ld b, $e
.sendLoop
    call ReadHeaderByte
    call SendByte
    dec b
    jr nz, .sendLoop
    
    ; Done bit
    ld a, $20
    ld [c], a
    ld a, $30
    ld [c], a
    
    ; Update command
    ldh a, [_HRAM]
    add 2
    ldh [_HRAM], a
    
    ld a, $58
    cp l
    jr nz, .sendCommand
    
    ; Write to sound registers for DMG compatibility
    ld c, $13
    ld a, $c1
    ld [c], a
    inc c
    ld a, 7
    ld [c], a
    
    ; Init BG palette
    ld a, $fc
    ldh [rBGP], a
    
; Set registers to match the original SGB boot
IF DEF(SGB2)
    ld a, $FF
ELSE
    ld a, 1
ENDC
    ld hl, $c060
    
; Boot the game
    jp BootGame

ReadHeaderByte:
    ld a, $4F
    cp l
    jr c, .zero
    ld a, [hli]
    ret
.zero:
    inc hl
    xor a
    ret

SendByte:
    ld e, a
    ld d, 8
.loop
    ld a, $10
    rr e
    jr c, .zeroBit
    add a ; 10 -> 20
.zeroBit
    ld [c], a
    ld a, $30
    ld [c], a
    dec d
    ret z
    jr .loop

DoubleBitsAndWriteRow:
; Double the most significant 4 bits, b is shifted by 4
    ld a, 4
    ld c, 0
.doubleCurrentBit
    sla b
    push af
    rl c
    pop af
    rl c
    dec a
    jr nz, .doubleCurrentBit
    ld a, c
; Write as two rows
    ldi [hl], a
    inc hl
    ldi [hl], a
    inc hl
    ret

WaitFrame:
    push hl
    ld hl, $FF0F
    res 0, [hl]
.wait
    bit 0, [hl]
    jr z, .wait
    pop hl
    ret

TrademarkSymbol:
db $3c,$42,$b9,$a5,$b9,$a5,$42,$3c

SECTION "BootGame", ROM0[$fe]
BootGame:
    ldh [rBANK], a